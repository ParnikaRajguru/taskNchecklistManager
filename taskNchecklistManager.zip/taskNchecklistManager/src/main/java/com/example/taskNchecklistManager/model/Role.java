package com.example.taskNchecklistManager.model;

public enum Role {
    MANAGER,
    STAFF
}

