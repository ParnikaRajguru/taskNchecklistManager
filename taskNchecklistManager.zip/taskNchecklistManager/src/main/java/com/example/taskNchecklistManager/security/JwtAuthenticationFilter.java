package com.example.taskNchecklistManager.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.security.core.userdetails.UserDetails;

import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;

import org.springframework.stereotype.Component;

import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;

    private final CustomUserDetailsService userDetailsService;

    public JwtAuthenticationFilter(
            JwtService jwtService,
            CustomUserDetailsService userDetailsService
    ) {

        this.jwtService = jwtService;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected boolean shouldNotFilter(
            HttpServletRequest request
    ) {

        String path = request.getServletPath();

        System.out.println("REQUEST PATH: " + path);

        return path.startsWith("/auth");
    }

    @Override
    protected void doFilterInternal(

            HttpServletRequest request,

            HttpServletResponse response,

            FilterChain filterChain

    ) throws ServletException, IOException {

        System.out.println("JWT FILTER EXECUTED");

        final String authHeader =
                request.getHeader("Authorization");

        System.out.println("AUTH HEADER: " + authHeader);

        final String jwt;

        final String userEmail;

        // NO TOKEN
        if (authHeader == null ||
                !authHeader.startsWith("Bearer ")) {

            System.out.println(
                    "NO VALID BEARER TOKEN FOUND"
            );

            filterChain.doFilter(request, response);

            return;
        }

        try {

            // REMOVE "Bearer "
            jwt = authHeader.substring(7);

            System.out.println("JWT TOKEN: " + jwt);

            // EXTRACT EMAIL
            userEmail = jwtService.extractEmail(jwt);

            System.out.println(
                    "EMAIL FROM TOKEN: " + userEmail
            );

            // USER NOT AUTHENTICATED YET
            if (userEmail != null &&

                    SecurityContextHolder
                            .getContext()
                            .getAuthentication() == null) {

                UserDetails userDetails =

                        userDetailsService
                                .loadUserByUsername(userEmail);

                System.out.println(
                        "USER DETAILS LOADED"
                );

                // VALIDATE TOKEN
                if (jwtService.isTokenValid(
                        jwt,
                        userDetails.getUsername()
                )) {

                    System.out.println(
                            "TOKEN VALIDATED SUCCESSFULLY"
                    );

                    UsernamePasswordAuthenticationToken authToken =

                            new UsernamePasswordAuthenticationToken(

                                    userDetails,

                                    null,

                                    userDetails.getAuthorities()
                            );

                    authToken.setDetails(

                            new WebAuthenticationDetailsSource()
                                    .buildDetails(request)
                    );

                    SecurityContextHolder
                            .getContext()
                            .setAuthentication(authToken);

                    System.out.println(
                            "USER AUTHENTICATED"
                    );
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "JWT ERROR: " + e.getMessage()
            );

            e.printStackTrace();
        }

        filterChain.doFilter(request, response);
    }
}