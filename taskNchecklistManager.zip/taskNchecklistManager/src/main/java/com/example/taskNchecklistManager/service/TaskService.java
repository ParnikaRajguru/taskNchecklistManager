package com.example.taskNchecklistManager.service;

import com.example.taskNchecklistManager.dto.CreateNoteRequest;
import com.example.taskNchecklistManager.dto.CreateTaskRequest;

import com.example.taskNchecklistManager.dto.response.*;

import com.example.taskNchecklistManager.model.*;

import com.example.taskNchecklistManager.repository.AuditLogRepository;
import com.example.taskNchecklistManager.repository.NoteRepository;
import com.example.taskNchecklistManager.repository.TaskRepository;
import com.example.taskNchecklistManager.repository.UserRepository;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

@Service
public class TaskService {

    private final TaskRepository taskRepository;

    private final UserRepository userRepository;

    private final AuditLogRepository auditLogRepository;

    private final NoteRepository noteRepository;

    private final CurrentUserService currentUserService;

    public TaskService(
            TaskRepository taskRepository,
            UserRepository userRepository,
            AuditLogRepository auditLogRepository,
            NoteRepository noteRepository,
            CurrentUserService currentUserService
    ) {

        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
        this.auditLogRepository = auditLogRepository;
        this.noteRepository = noteRepository;
        this.currentUserService = currentUserService;
    }

    // CREATE TASK
    public TaskResponseDTO createTask(CreateTaskRequest request) {

        // CURRENT LOGGED-IN USER
        User manager = currentUserService.getCurrentUser();

        // VALIDATE ROLE
        if (manager.getRole() != Role.MANAGER) {

            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Only managers can create tasks"
            );
        }

        // FIND STAFF
        User staff = userRepository.findById(request.getAssignedToId())
                .orElseThrow(() ->
                        new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Staff not found"
                        )
                );

        // VALIDATE STAFF BELONGS TO MANAGER
        if (staff.getManager() == null ||
                !staff.getManager().getId().equals(manager.getId())) {

            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "This staff does not belong to manager"
            );
        }

        // CREATE TASK
        Task task = new Task();

        task.setTitle(request.getTitle());

        task.setDescription(request.getDescription());

        task.setStatus(TaskStatus.PENDING);

        task.setCreatedAt(LocalDateTime.now());

        task.setCreatedBy(manager);

        task.setAssignedTo(staff);

        // SAVE TASK
        Task savedTask = taskRepository.save(task);

        // CREATE AUDIT LOG
        AuditLog log = new AuditLog();

        log.setAction("TASK_CREATED");

        log.setTimestamp(LocalDateTime.now());

        log.setTask(savedTask);

        log.setPerformedBy(manager);

        auditLogRepository.save(log);

        return mapTask(savedTask);
    }

    // GET TASKS
    public Page<TaskResponseDTO> getTasks(
            int page,
            int size,
            String sortBy
    ) {

        User currentUser =
                currentUserService.getCurrentUser();

        Pageable pageable = PageRequest.of(
                page,
                size,
                Sort.by(sortBy).descending()
        );

        Page<Task> tasks;

        // MANAGER
        if (currentUser.getRole() == Role.MANAGER) {

            tasks = taskRepository.findByCreatedById(
                    currentUser.getId(),
                    pageable
            );
        }

        // STAFF
        else {

            tasks = taskRepository.findByAssignedToId(
                    currentUser.getId(),
                    pageable
            );
        }

        return tasks.map(this::mapTask);
    }


    // COMPLETE TASK
    public TaskResponseDTO completeTask(Long taskId) {

        // FIND TASK
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() ->
                        new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Task not found"
                        )
                );

        // CURRENT USER
        User user = currentUserService.getCurrentUser();

        // VALIDATE TASK BELONGS TO STAFF
        if (!task.getAssignedTo().getId().equals(user.getId())) {

            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "You are not assigned to this task"
            );
        }

        // TASK ALREADY COMPLETED
        if (task.getStatus() == TaskStatus.COMPLETED) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Task already completed"
            );
        }

        // UPDATE TASK
        task.setStatus(TaskStatus.COMPLETED);

        task.setCompletedAt(LocalDateTime.now());

        // SAVE TASK
        Task updatedTask = taskRepository.save(task);

        // CREATE AUDIT LOG
        AuditLog log = new AuditLog();

        log.setAction("TASK_COMPLETED");

        log.setTimestamp(LocalDateTime.now());

        log.setTask(updatedTask);

        log.setPerformedBy(user);

        auditLogRepository.save(log);

        return mapTask(updatedTask);
    }

    // ADD NOTE
    public Note addNote(
            Long taskId,
            CreateNoteRequest request
    ) {

        // FIND TASK
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() ->
                        new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Task not found"
                        )
                );

        // CURRENT USER
        User user = currentUserService.getCurrentUser();

        // CREATE NOTE
        Note note = new Note();

        note.setContent(request.getContent());

        note.setCreatedAt(LocalDateTime.now());

        note.setTask(task);

        note.setUser(user);

        // SAVE NOTE
        Note savedNote = noteRepository.save(note);

        // CREATE AUDIT LOG
        AuditLog log = new AuditLog();

        log.setAction("NOTE_ADDED");

        log.setTimestamp(LocalDateTime.now());

        log.setTask(task);

        log.setPerformedBy(user);

        auditLogRepository.save(log);

        return savedNote;
    }

    // GET AUDIT LOGS
    public List<AuditLogResponseDTO> getAuditLogs() {

        return auditLogRepository.findAll()
                .stream()
                .map(this::mapAuditLog)
                .toList();
    }

    public Page<TaskResponseDTO> filterTasksByStatus(
            TaskStatus status,
            int page,
            int size
    ) {

        Pageable pageable =
                PageRequest.of(page, size);

        Page<Task> tasks =
                taskRepository.findByStatus(
                        status,
                        pageable
                );

        return tasks.map(this::mapTask);
    }

    // USER -> DTO
    private UserSummaryDTO mapUser(User user) {

        return new UserSummaryDTO(
                user.getId(),
                user.getName(),
                user.getRole().name()
        );
    }

    public Page<TaskResponseDTO> searchTasks(
            String keyword,
            int page,
            int size
    ) {

        Pageable pageable =
                PageRequest.of(page, size);

        Page<Task> tasks =
                taskRepository
                        .findByTitleContainingIgnoreCase(
                                keyword,
                                pageable
                        );

        return tasks.map(this::mapTask);
    }

    // TASK -> DTO
    private TaskResponseDTO mapTask(Task task) {

        TaskResponseDTO dto = new TaskResponseDTO();

        dto.setId(task.getId());

        dto.setTitle(task.getTitle());

        dto.setDescription(task.getDescription());

        dto.setStatus(task.getStatus().name());

        dto.setCreatedAt(task.getCreatedAt());

        dto.setCompletedAt(task.getCompletedAt());

        dto.setCreatedBy(mapUser(task.getCreatedBy()));

        dto.setAssignedTo(mapUser(task.getAssignedTo()));

        return dto;
    }

    // AUDIT -> DTO
    private AuditLogResponseDTO mapAuditLog(AuditLog log) {

        AuditLogResponseDTO dto = new AuditLogResponseDTO();

        dto.setId(log.getId());

        dto.setAction(log.getAction());

        dto.setTimestamp(log.getTimestamp());

        dto.setTaskTitle(log.getTask().getTitle());

        dto.setPerformedBy(mapUser(log.getPerformedBy()));

        return dto;
    }
}