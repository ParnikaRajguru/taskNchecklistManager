package com.example.taskNchecklistManager.controller;

import com.example.taskNchecklistManager.dto.CreateNoteRequest;
import com.example.taskNchecklistManager.dto.CreateTaskRequest;

import com.example.taskNchecklistManager.dto.response.ApiResponse;
import com.example.taskNchecklistManager.dto.response.AuditLogResponseDTO;
import com.example.taskNchecklistManager.dto.response.TaskResponseDTO;

import com.example.taskNchecklistManager.model.Note;
import com.example.taskNchecklistManager.model.TaskStatus;

import com.example.taskNchecklistManager.service.TaskService;

import jakarta.validation.Valid;

import org.springframework.data.domain.Page;

import org.springframework.http.ResponseEntity;

import org.springframework.security.access.prepost.PreAuthorize;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    // CREATE TASK
    @PreAuthorize("hasRole('MANAGER')")
    @PostMapping
    public ResponseEntity<ApiResponse<TaskResponseDTO>> createTask(
            @Valid @RequestBody CreateTaskRequest request
    ) {

        TaskResponseDTO createdTask =
                taskService.createTask(request);

        return ResponseEntity.ok(

                new ApiResponse<>(
                        true,
                        "Task created successfully",
                        createdTask
                )
        );
    }

    // GET TASKS
    @PreAuthorize("hasAnyRole('MANAGER', 'STAFF')")
    @GetMapping
    public ResponseEntity<ApiResponse<Page<TaskResponseDTO>>> getTasks(

            @RequestParam(defaultValue = "0")
            int page,

            @RequestParam(defaultValue = "5")
            int size,

            @RequestParam(defaultValue = "createdAt")
            String sortBy
    ) {

        Page<TaskResponseDTO> tasks =
                taskService.getTasks(
                        page,
                        size,
                        sortBy
                );

        return ResponseEntity.ok(

                new ApiResponse<>(
                        true,
                        "Tasks fetched successfully",
                        tasks
                )
        );
    }

    // COMPLETE TASK
    @PreAuthorize("hasRole('STAFF')")
    @PutMapping("/{taskId}/complete")
    public ResponseEntity<ApiResponse<TaskResponseDTO>> completeTask(
            @PathVariable Long taskId
    ) {

        TaskResponseDTO updatedTask =
                taskService.completeTask(taskId);

        return ResponseEntity.ok(

                new ApiResponse<>(
                        true,
                        "Task completed successfully",
                        updatedTask
                )
        );
    }

    // ADD NOTE
    @PreAuthorize("hasAnyRole('MANAGER', 'STAFF')")
    @PostMapping("/{taskId}/notes")
    public ResponseEntity<ApiResponse<Note>> addNote(

            @PathVariable Long taskId,

            @Valid @RequestBody CreateNoteRequest request
    ) {

        Note savedNote =
                taskService.addNote(taskId, request);

        return ResponseEntity.ok(

                new ApiResponse<>(
                        true,
                        "Note added successfully",
                        savedNote
                )
        );
    }

    // GET AUDIT LOGS
    @PreAuthorize("hasRole('MANAGER')")
    @GetMapping("/audit")
    public ResponseEntity<
            ApiResponse<List<AuditLogResponseDTO>>
            > getAuditLogs() {

        List<AuditLogResponseDTO> logs =
                taskService.getAuditLogs();

        return ResponseEntity.ok(

                new ApiResponse<>(
                        true,
                        "Audit logs fetched successfully",
                        logs
                )
        );
    }

    // FILTER TASKS
    @PreAuthorize("hasAnyRole('MANAGER', 'STAFF')")
    @GetMapping("/filter")
    public ResponseEntity<
            ApiResponse<Page<TaskResponseDTO>>
            > filterTasks(

            @RequestParam TaskStatus status,

            @RequestParam(defaultValue = "0")
            int page,

            @RequestParam(defaultValue = "5")
            int size
    ) {

        Page<TaskResponseDTO> tasks =
                taskService.filterTasksByStatus(
                        status,
                        page,
                        size
                );

        return ResponseEntity.ok(

                new ApiResponse<>(
                        true,
                        "Tasks filtered successfully",
                        tasks
                )
        );
    }

    // SEARCH TASKS
    @PreAuthorize("hasAnyRole('MANAGER', 'STAFF')")
    @GetMapping("/search")
    public ResponseEntity<
            ApiResponse<Page<TaskResponseDTO>>
            > searchTasks(

            @RequestParam String keyword,

            @RequestParam(defaultValue = "0")
            int page,

            @RequestParam(defaultValue = "5")
            int size
    ) {

        Page<TaskResponseDTO> tasks =
                taskService.searchTasks(
                        keyword,
                        page,
                        size
                );

        return ResponseEntity.ok(

                new ApiResponse<>(
                        true,
                        "Tasks fetched successfully",
                        tasks
                )
        );
    }
}