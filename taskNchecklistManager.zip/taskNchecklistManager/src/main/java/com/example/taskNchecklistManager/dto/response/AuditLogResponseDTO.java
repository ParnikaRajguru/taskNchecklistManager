package com.example.taskNchecklistManager.dto.response;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class AuditLogResponseDTO {

    private Long id;

    private String action;

    private LocalDateTime timestamp;

    private String taskTitle;

    private UserSummaryDTO performedBy;
}
