package com.example.taskNchecklistManager.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class AuthResponse {

    private String message;

    private String token;

    private Long userId;

    private String role;
}
