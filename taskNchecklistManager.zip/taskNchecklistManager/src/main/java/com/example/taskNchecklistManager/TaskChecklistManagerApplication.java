package com.example.taskNchecklistManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskChecklistManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskChecklistManagerApplication.class, args);
	}

}
