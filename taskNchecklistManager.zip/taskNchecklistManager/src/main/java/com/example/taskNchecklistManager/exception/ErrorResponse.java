package com.example.taskNchecklistManager.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
@AllArgsConstructor
public class ErrorResponse {

    private boolean success;

    private LocalDateTime timestamp;

    private int status;

    private String message;
}