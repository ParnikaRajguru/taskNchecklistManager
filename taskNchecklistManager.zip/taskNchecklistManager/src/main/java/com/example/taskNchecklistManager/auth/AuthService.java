package com.example.taskNchecklistManager.auth;

import com.example.taskNchecklistManager.dto.RegisterRequest;
import com.example.taskNchecklistManager.model.Role;
import com.example.taskNchecklistManager.model.User;
import com.example.taskNchecklistManager.repository.UserRepository;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.taskNchecklistManager.dto.LoginRequest;
import com.example.taskNchecklistManager.dto.response.AuthResponse;
import org.springframework.web.server.ResponseStatusException;
import com.example.taskNchecklistManager.security.JwtService;

import java.time.LocalDateTime;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       JwtService jwtService) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public User register(RegisterRequest request) {

        // CHECK EMAIL EXISTS
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Email already exists");
        }

        User user = new User();

        user.setName(request.getName());
        user.setEmail(request.getEmail());

        // HASH PASSWORD
        user.setPassword(
                passwordEncoder.encode(request.getPassword())
        );

        user.setRole(Role.valueOf(request.getRole()));

        user.setCreatedAt(LocalDateTime.now());

        // STAFF -> assign manager
        if (user.getRole() == Role.STAFF &&
                request.getManagerId() != null) {

            User manager = userRepository.findById(request.getManagerId())
                    .orElseThrow(() ->
                            new RuntimeException("Manager not found"));

            user.setManager(manager);
        }

        return userRepository.save(user);
    }

    public AuthResponse login(LoginRequest request) {

        // FIND USER
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() ->
                        new RuntimeException("Invalid email or password"));

        // CHECK PASSWORD
        boolean matches = passwordEncoder.matches(
                request.getPassword(),
                user.getPassword()
        );

        if (!matches) {
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Invalid email or password"
            );        }

        String token = jwtService.generateToken(user.getEmail());

        return new AuthResponse(
                "Login successful",
                token,
                user.getId(),
                user.getRole().name()
        );
    }

}
