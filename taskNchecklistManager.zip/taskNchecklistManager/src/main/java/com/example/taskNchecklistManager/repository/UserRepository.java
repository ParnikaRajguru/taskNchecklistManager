package com.example.taskNchecklistManager.repository;

import com.example.taskNchecklistManager.model.User;
import com.example.taskNchecklistManager.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    List<User> findByRole(Role role);

    List<User> findByManagerId(Long managerId);
}
