package com.example.taskNchecklistManager.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "tasks")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @Column(length = 1000)
    private String description;

    @Enumerated(EnumType.STRING)
    private TaskStatus status;

    private LocalDateTime createdAt;

    private LocalDateTime completedAt;

    /*
     * Manager who created task
     */
    @ManyToOne
    @JoinColumn(name = "created_by")
    private User createdBy;

    /*
     * Staff assigned task
     */
    @ManyToOne
    @JoinColumn(name = "assigned_to")
    private User assignedTo;

    /*
     * One task can have many notes
     */
    @JsonIgnore
    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL)
    private List<Note> notes;

    /*
     * One task can have many audit logs
     */
    @JsonIgnore
    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL)
    private List<AuditLog> auditLogs;
}