package com.example.taskNchecklistManager.repository;

import com.example.taskNchecklistManager.model.Task;
import com.example.taskNchecklistManager.model.TaskStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {

    Page<Task> findByCreatedById(
            Long id,
            Pageable pageable
    );

    Page<Task> findByAssignedToId(
            Long id,
            Pageable pageable
    );

    Page<Task> findByStatus(
            TaskStatus status,
            Pageable pageable
    );

    Page<Task> findByTitleContainingIgnoreCase(
            String keyword,
            Pageable pageable
    );
}
