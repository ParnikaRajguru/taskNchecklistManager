package com.example.taskNchecklistManager.model;

import jakarta.persistence.*;
import lombok.*;
import com.fasterxml.jackson.annotation.JsonIgnore;


import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(unique = true)
    private String email;

    private String password;

    @Enumerated(EnumType.STRING)
    private Role role;

    private LocalDateTime createdAt;

    // STAFF -> belongs to one manager
    @ManyToOne
    @JoinColumn(name = "manager_id")
    private User manager;

    // MANAGER -> has many staff
    @JsonIgnore
    @OneToMany(mappedBy = "manager")
    private List<User> staffMembers;
}
