package com.example.taskNchecklistManager.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "notes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Note {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 1000)
    private String content;

    private LocalDateTime createdAt;

    /*
     * Many notes belong to one task
     */
    @ManyToOne
    @JoinColumn(name = "task_id")
    private Task task;

    /*
     * Many notes can be added by one user
     */
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
}
