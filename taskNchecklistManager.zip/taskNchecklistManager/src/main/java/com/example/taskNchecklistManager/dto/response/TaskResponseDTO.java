package com.example.taskNchecklistManager.dto.response;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class TaskResponseDTO {

    private Long id;

    private String title;

    private String description;

    private String status;

    private LocalDateTime createdAt;

    private LocalDateTime completedAt;

    private UserSummaryDTO createdBy;

    private UserSummaryDTO assignedTo;
}
