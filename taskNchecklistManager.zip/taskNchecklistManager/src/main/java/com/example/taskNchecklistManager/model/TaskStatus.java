package com.example.taskNchecklistManager.model;

public enum TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
