package com.example.taskNchecklistManager.auth;

import com.example.taskNchecklistManager.dto.RegisterRequest;
import com.example.taskNchecklistManager.model.User;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.taskNchecklistManager.dto.LoginRequest;
import com.example.taskNchecklistManager.dto.response.AuthResponse;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<User> register(
           @Valid @RequestBody RegisterRequest request) {

        User savedUser = authService.register(request);

        return ResponseEntity.ok(savedUser);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(
            @Valid @RequestBody LoginRequest request) {

        AuthResponse response = authService.login(request);

        return ResponseEntity.ok(response);
    }
}
