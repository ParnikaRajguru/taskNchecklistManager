package com.example.taskNchecklistManager.dto;

import jakarta.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateNoteRequest {

    @NotBlank(message = "Note content is required")
    private String content;
}