package com.example.taskNchecklistManager.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "audit_logs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String action;

    private LocalDateTime timestamp;

    /*
     * Many audit logs belong to one task
     */
    @ManyToOne
    @JoinColumn(name = "task_id")
    private Task task;

    /*
     * User who performed action
     */
    @ManyToOne
    @JoinColumn(name = "performed_by")
    private User performedBy;
}
