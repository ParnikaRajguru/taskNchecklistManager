package com.example.taskNchecklistManager.repository;

import com.example.taskNchecklistManager.model.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    List<AuditLog> findByTaskId(Long taskId);
    List<AuditLog> findByPerformedById(Long userId);
}
