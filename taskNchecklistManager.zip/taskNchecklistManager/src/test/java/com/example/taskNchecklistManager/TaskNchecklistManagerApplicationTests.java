package com.example.taskNchecklistManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskNchecklistManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
